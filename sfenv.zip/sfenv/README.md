


sfenv - applys an envelope based on provided breakpoint file to a supplied audio file

Usage: ./sfenv {audio infile}  {breakpoint infile} {name of file to create}

Notes: - breakpoint files must not have negative time values and each breakpoint must be on a new line. See provided examples
