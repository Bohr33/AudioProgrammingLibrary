

SFENV

This is an envelope function that when given an input file and a breakpoint file, will produce a new audio file with the given breakpoint file as applied to its amplitude.